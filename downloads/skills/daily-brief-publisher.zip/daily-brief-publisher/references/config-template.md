# Configuration Template

Use this template when setting up a daily brief publisher. Replace every placeholder before activating production delivery.

## Required Values

```yaml
automation:
  name: "<AUTOMATION_NAME>"
  schedule_rrule: "RRULE:FREQ=DAILY;BYHOUR=<HOUR>;BYMINUTE=<MINUTE>"
  timezone: "<IANA_TIMEZONE>"
  model: "<MODEL_NAME>"

brief:
  title_template: "<BRIEF_TITLE> - YYYY-MM-DD"
  language: "<LANGUAGE>"
  topic_scope:
    - "<TOPIC_OR_QUERY_1>"
    - "<TOPIC_OR_QUERY_2>"
  preferred_sources:
    - "<SOURCE_1>"
    - "<SOURCE_2>"
  exclusion_rules:
    - "<WHAT_TO_EXCLUDE>"
  output_markdown_dir: "<ABSOLUTE_LOCAL_OUTPUT_DIR>"

email:
  enabled: true
  tool: "<EMAIL_TOOL_OR_CONNECTOR>"
  recipients:
    - "<RECIPIENT_EMAIL>"
  subject_template: "<EMAIL_SUBJECT>｜YYYY-MM-DD"

github_pages:
  enabled: true
  owner: "<GITHUB_OWNER>"
  repo: "<GITHUB_PAGES_REPO>"
  branch: "<BRANCH>"
  local_repo_dir: "<ABSOLUTE_LOCAL_REPO_CLONE>"
  section_path: "<SITE_SECTION_PATH>"
  public_base_url: "<PUBLIC_GITHUB_PAGES_BASE_URL>/<SITE_SECTION_PATH>/"

search:
  dimensions:
    - "date"
    - "topic"
    - "<CUSTOM_DIMENSION>"
  tags:
    - "<TAG_1>"
    - "<TAG_2>"
```

## Automation Prompt Checklist

The automation prompt should say:

- Generate a complete Markdown report for the configured date/timezone.
- Save it to `<ABSOLUTE_LOCAL_OUTPUT_DIR>/YYYY-MM-DD.md`.
- Publish it to GitHub Pages under `<SITE_SECTION_PATH>/briefs/YYYY-MM-DD.md`.
- Update `<SITE_SECTION_PATH>/index.html`, `<SITE_SECTION_PATH>/reader.html`, and `<SITE_SECTION_PATH>/search.json`.
- Send email to exactly the configured recipients after verifying addresses.
- If email or publishing fails, output the full Markdown and explicit failure reason.
- Do not silently skip missing current-data retrieval when current events are required.

## Backfill Checklist

- Source of truth for each historical date: `<MARKDOWN | SENT_EMAIL | LOG | MEMORY_SUMMARY | OTHER>`.
- Dates included: `<DATE_RANGE>`.
- Full Markdown available: `<YES_OR_NO>`.
- If only summary-level data exists, label it as summary-only.
- Verify every published historical URL that was added.
