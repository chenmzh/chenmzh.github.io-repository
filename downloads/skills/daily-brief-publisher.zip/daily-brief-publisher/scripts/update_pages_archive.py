#!/usr/bin/env python3
"""Build a static GitHub Pages archive from dated Markdown briefs."""

from __future__ import annotations

import argparse
import html
import json
import re
import shutil
from dataclasses import dataclass
from pathlib import Path


DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
LINK_RE = re.compile(r"\[([^\]]+)\]\((https?://[^)]+)\)")


@dataclass
class Brief:
    date: str
    title: str
    summary: str
    items: list[str]
    tags: list[str]
    markdown: str
    url: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--markdown-dir", required=True, type=Path)
    parser.add_argument("--site-dir", required=True, type=Path)
    parser.add_argument("--title", required=True)
    parser.add_argument("--base-url", default="")
    parser.add_argument(
        "--tag-query",
        default="",
        help="Optional regex with matches used as tags, e.g. '(AI|Biology|Finance)'.",
    )
    parser.add_argument(
        "--clean-briefs",
        action="store_true",
        help="Remove existing Markdown files in site-dir/briefs before copying.",
    )
    return parser.parse_args()


def strip_markdown(text: str) -> str:
    text = LINK_RE.sub(r"\1", text)
    text = re.sub(r"`([^`]+)`", r"\1", text)
    text = re.sub(r"[*_>#-]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def first_heading(lines: list[str], fallback: str) -> str:
    for line in lines:
        if line.startswith("# "):
            return line[2:].strip()
    return fallback


def first_paragraph(lines: list[str]) -> str:
    chunks: list[str] = []
    in_heading = True
    for line in lines:
        s = line.strip()
        if not s:
            if chunks:
                break
            continue
        if in_heading and s.startswith("#"):
            continue
        in_heading = False
        if s.startswith("#"):
            continue
        chunks.append(s)
    return strip_markdown(" ".join(chunks))[:360]


def extract_items(lines: list[str]) -> list[str]:
    items: list[str] = []
    for line in lines:
        s = line.strip()
        if s.startswith("### "):
            item = strip_markdown(s[4:])
        elif re.match(r"^[-*]\s+", s):
            item = strip_markdown(re.sub(r"^[-*]\s+", "", s))
        else:
            continue
        if item and item not in items:
            items.append(item)
        if len(items) >= 12:
            break
    return items


def extract_tags(text: str, pattern: str) -> list[str]:
    tags: list[str] = []
    if pattern:
        regex = re.compile(pattern, re.IGNORECASE)
        for match in regex.finditer(text):
            value = next((g for g in match.groups() if g), match.group(0))
            value = value.strip()
            if value and value not in tags:
                tags.append(value)
    return tags[:12]


def load_briefs(markdown_dir: Path, tag_query: str) -> list[Brief]:
    briefs: list[Brief] = []
    for path in sorted(markdown_dir.glob("*.md"), reverse=True):
        date = path.stem
        if not DATE_RE.fullmatch(date):
            continue
        text = path.read_text(encoding="utf-8")
        lines = text.splitlines()
        title = first_heading(lines, date)
        briefs.append(
            Brief(
                date=date,
                title=title,
                summary=first_paragraph(lines),
                items=extract_items(lines),
                tags=extract_tags(text, tag_query),
                markdown=f"briefs/{date}.md",
                url=f"reader.html?date={date}",
            )
        )
    return briefs


def write_search_json(site_dir: Path, briefs: list[Brief]) -> None:
    payload = {
        "updated": briefs[0].date if briefs else "",
        "briefs": [brief.__dict__ for brief in briefs],
    }
    (site_dir / "search.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def write_index(site_dir: Path, title: str) -> None:
    escaped_title = html.escape(title)
    content = f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escaped_title}</title>
  <style>
    body {{ margin:0; font:16px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; color:#17202a; background:#f7f8fb; }}
    main {{ max-width:1080px; margin:0 auto; padding:28px 18px 48px; }}
    h1 {{ margin:0 0 14px; font-size:32px; line-height:1.15; }}
    .controls {{ display:grid; grid-template-columns:1fr 180px; gap:12px; margin:20px 0; }}
    input, select {{ font:inherit; padding:10px 12px; border:1px solid #cfd6e2; border-radius:6px; background:#fff; }}
    .grid {{ display:grid; gap:12px; }}
    .card {{ display:block; text-decoration:none; color:inherit; background:#fff; border:1px solid #d8dee8; border-radius:8px; padding:16px; }}
    .meta {{ color:#667085; font-size:14px; margin-bottom:6px; }}
    .tags {{ color:#335c81; font-size:14px; margin-top:8px; }}
    @media (max-width:700px) {{ .controls {{ grid-template-columns:1fr; }} h1 {{ font-size:26px; }} }}
  </style>
</head>
<body>
<main>
  <h1>{escaped_title}</h1>
  <div class="controls">
    <input id="q" type="search" placeholder="搜索日期、标题、摘要、条目或标签">
    <select id="tag"><option value="">全部标签</option></select>
  </div>
  <div id="list" class="grid"></div>
</main>
<script>
const q = document.getElementById('q');
const tag = document.getElementById('tag');
const list = document.getElementById('list');
let briefs = [];
function esc(s) {{ return (s || '').replace(/[&<>"]/g, c => ({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}}[c])); }}
function searchable(b) {{ return [b.date,b.title,b.summary,(b.items||[]).join(' '),(b.tags||[]).join(' ')].join(' ').toLowerCase(); }}
function render() {{
  const needle = q.value.trim().toLowerCase();
  const selected = tag.value;
  const rows = briefs.filter(b => (!needle || searchable(b).includes(needle)) && (!selected || (b.tags||[]).includes(selected)));
  list.innerHTML = rows.map(b => `<a class="card" href="${{esc(b.url)}}">
    <div class="meta">${{esc(b.date)}}</div>
    <strong>${{esc(b.title)}}</strong>
    <p>${{esc(b.summary || '')}}</p>
    <div class="tags">${{(b.tags || []).map(esc).join(' / ')}}</div>
  </a>`).join('') || '<p>没有匹配结果。</p>';
}}
fetch('search.json').then(r => r.json()).then(data => {{
  briefs = data.briefs || [];
  const tags = [...new Set(briefs.flatMap(b => b.tags || []))].sort();
  tag.innerHTML += tags.map(t => `<option value="${{esc(t)}}">${{esc(t)}}</option>`).join('');
  render();
}});
q.addEventListener('input', render);
tag.addEventListener('change', render);
</script>
</body>
</html>
"""
    (site_dir / "index.html").write_text(content, encoding="utf-8")


def write_reader(site_dir: Path, title: str) -> None:
    escaped_title = html.escape(title)
    content = f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escaped_title}</title>
  <style>
    body {{ margin:0; font:17px/1.68 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; color:#17202a; background:#f7f8fb; }}
    main {{ max-width:900px; margin:0 auto; padding:28px 18px 50px; }}
    article {{ background:#fff; border:1px solid #d8dee8; border-radius:8px; padding:26px; }}
    a {{ color:#1769aa; }} h1 {{ line-height:1.2; }} h2 {{ margin-top:32px; border-top:1px solid #edf0f5; padding-top:20px; }}
    code {{ background:#f1f4f8; padding:2px 5px; border-radius:4px; }} pre {{ overflow:auto; background:#f1f4f8; padding:12px; border-radius:6px; }}
    .top {{ margin-bottom:18px; }} .top a {{ text-decoration:none; }}
    @media (max-width:680px) {{ article{{padding:18px;}} body{{font-size:16px;}} }}
  </style>
</head>
<body>
<main>
  <div class="top"><a href="index.html">返回检索页</a></div>
  <article id="content">加载中...</article>
</main>
<script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
<script>
const date = new URLSearchParams(location.search).get('date');
const content = document.getElementById('content');
if (!date || !/^\\d{{4}}-\\d{{2}}-\\d{{2}}$/.test(date)) {{
  content.textContent = '缺少有效日期。';
}} else {{
  fetch(`briefs/${{date}}.md`).then(r => {{
    if (!r.ok) throw new Error('not found');
    return r.text();
  }}).then(md => {{
    document.title = `{escaped_title} ${{date}}`;
    content.innerHTML = marked.parse(md);
  }}).catch(() => {{
    content.textContent = '没有找到这一天的简报 Markdown。';
  }});
}}
</script>
</body>
</html>
"""
    (site_dir / "reader.html").write_text(content, encoding="utf-8")


def main() -> None:
    args = parse_args()
    markdown_dir = args.markdown_dir.expanduser().resolve()
    site_dir = args.site_dir.expanduser().resolve()
    if not markdown_dir.is_dir():
        raise SystemExit(f"Markdown directory not found: {markdown_dir}")

    site_dir.mkdir(parents=True, exist_ok=True)
    briefs_dir = site_dir / "briefs"
    briefs_dir.mkdir(exist_ok=True)
    if args.clean_briefs:
        for old in briefs_dir.glob("*.md"):
            old.unlink()

    briefs = load_briefs(markdown_dir, args.tag_query)
    for brief in briefs:
        shutil.copy2(markdown_dir / f"{brief.date}.md", briefs_dir / f"{brief.date}.md")

    write_search_json(site_dir, briefs)
    write_index(site_dir, args.title)
    write_reader(site_dir, args.title)

    print(f"Archive updated: {site_dir}")
    print(f"Markdown files: {len(briefs)}")
    if args.base_url:
        print(f"Public root: {args.base_url.rstrip('/')}/")


if __name__ == "__main__":
    main()
