---
name: daily-brief-publisher
description: "Create or update recurring Codex automations that generate Markdown daily or periodic briefs, send scheduled email delivery, publish the same Markdown archive to a GitHub Pages website, and provide searchable date/topic indexes. Use when the user asks to make a scheduled newsletter, daily report, research brief, market brief, news digest, automation, email brief, GitHub Pages archive, markdown backfill, searchable brief website, or reusable publishing workflow. The skill is privacy-preserving: require the user to provide their own email, repository, website URL, paths, schedule, and topic settings."
---

# Daily Brief Publisher

## Core Rule

Never hard-code personal information. Treat email addresses, GitHub owners/repos, branch names, public URLs, local paths, automation IDs, topics, sources, schedules, and API/service names as user-provided configuration. If a required value is missing and cannot be discovered safely from the current request, ask for it or leave an explicit placeholder.

Read `references/config-template.md` when creating a new automation or documenting setup values.

## Workflow

1. Collect configuration:
   - Report title and topic scope.
   - Schedule and timezone.
   - Output Markdown directory.
   - Email sender/tool and recipient list.
   - GitHub Pages repository, branch, public base URL, and section path.
   - Search dimensions such as topic tags, markets, tickers, sources, or authors.
   - Backfill source, if any: existing Markdown, sent email, local logs, or automation memory.

2. Create or update the recurring automation:
   - Use the automation tool when available; do not edit automation internals by hand unless no tool exists.
   - Preserve existing delivery behavior unless the user asks to change it.
   - In the automation prompt, require:
     - Web/source retrieval when the report depends on current events.
     - A full Markdown file saved to the configured output directory as `YYYY-MM-DD.md`.
     - Email delivery with exact recipient verification.
     - GitHub Pages publication to the configured repo/path.
     - `index.html`, `reader.html`, `search.json`, and `briefs/YYYY-MM-DD.md` kept in sync.
     - Clear failure reporting if email, network, or GitHub publication fails.

3. Prepare the GitHub Pages archive:
   - Clone or open the user-provided Pages repo.
   - Place the archive under the configured section path, for example `<SECTION_PATH>/`.
   - Store Markdown files in `<SECTION_PATH>/briefs/YYYY-MM-DD.md`.
   - Keep a static `index.html` for date/topic search and `reader.html?date=YYYY-MM-DD` for rendering Markdown.
   - Keep `search.json` small and deterministic; include date, title, tags, summary, item titles, markdown path, and reader URL.

4. Backfill:
   - Prefer existing Markdown files.
   - If Markdown is absent, use the user's approved source such as sent emails or local automation logs.
   - Do not invent missing historical content. If only summaries exist, mark the backfill as summary-level.
   - Publish full Markdown when full bodies are available.

5. Verify:
   - Validate JSON with a parser.
   - Check git status before commit.
   - Commit with a narrow message such as `Add daily brief archive` or `Backfill daily brief markdown`.
   - Push to the configured branch.
   - Verify public URLs with HTTP checks:
     - Archive root.
     - `search.json`.
     - At least one recent Markdown file.
     - All backfilled Markdown files when the count is reasonable.
   - Allow for GitHub Pages cache delay and retry before diagnosing.

6. Persist operational memory:
   - Record the public URL, repo/path, output directory, commit SHA, dates backfilled, and verification result in the automation memory or local run notes.
   - Do not record secrets or private tokens.

## Script

Use `scripts/update_pages_archive.py` to copy Markdown files into a static GitHub Pages archive and regenerate `search.json`, `index.html`, and `reader.html`.

Typical use:

```bash
python3 scripts/update_pages_archive.py \
  --markdown-dir <LOCAL_MARKDOWN_DIR> \
  --site-dir <LOCAL_PAGES_REPO>/<SECTION_PATH> \
  --title "<ARCHIVE_TITLE>" \
  --base-url "<PUBLIC_BASE_URL>/<SECTION_PATH>/" \
  --tag-query "<OPTIONAL_REGEX_FOR_TAGS>"
```

The script does not commit or push. Review its output, then use git commands in the Pages repo.

## Quality Bar

- Keep Markdown as the source of truth.
- Preserve source links as Markdown links.
- Make generated pages static and dependency-light.
- Prefer explicit dates and timezones.
- Keep generated archive files deterministic so git diffs stay clean.
- State any data limitations directly in the brief or run notes.
